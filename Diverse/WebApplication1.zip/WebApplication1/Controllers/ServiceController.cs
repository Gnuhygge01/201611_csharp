﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ServiceController : Controller
    {
        [Route("~/api/HentKunder")]
        public ActionResult HentKunder(int? antal)
        {
            int i = 1;
            if (antal.HasValue)
                i = antal.Value;
            var r = new Repository();
            var lst = r.HentKonti(i);
            return Json(lst, JsonRequestBehavior.AllowGet);
        }
    }
}