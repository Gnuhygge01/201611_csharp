﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Repository
    {
        public List<Konto> HentKonti(int antal) {

            List<Konto> lst = new List<Konto>();
            for (int i = 0; i < antal; i++)
            {
                lst.Add(new Konto() { Navn = "test1", Nummer = "1" });
            }
            return lst;

        }
    }
}